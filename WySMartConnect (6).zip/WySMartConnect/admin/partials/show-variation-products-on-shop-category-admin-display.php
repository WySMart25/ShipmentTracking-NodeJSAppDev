<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://https://codingkart.com/
 * @since      1.0.0
 *
 * @package    Show_Variation_Products_On_Shop_Category
 * @subpackage Show_Variation_Products_On_Shop_Category/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
